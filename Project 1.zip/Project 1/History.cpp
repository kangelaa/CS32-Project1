//
//  History.cpp
//  Project 1
//
//  Created by Angela Kan on 1/12/21.
//

#include "History.h"
#include "globals.h"

#include <iostream>

using namespace std;

///////////////////////////////////////////////////////////////////////////
//  History implementation
///////////////////////////////////////////////////////////////////////////

History::History(int nRows, int nCols)
{
    m_rows = nRows;
    m_cols = nCols;
    for (int i=1; i<=m_rows; i++){
        for (int j=1; j<=m_cols; j++){
            hist[i][j] = 'A' - 1;
        }
    }
}

bool History::record(int r, int c){
    if (r>m_rows || r<1 || c>m_cols || c<1){
        return false;
    } else {
        if (hist[r][c] != 'Z'){
            hist[r][c]++;
        }
        return true;
    }
}

void History::display() const {
    clearScreen();
    for (int i=1; i<=m_rows; i++){
        for (int j=1; j<=m_cols; j++){
            if (hist[i][j] == 'A' - 1){
                cout << ".";
            } else {
                cout << hist[i][j];
            }
        }
        cout << endl;
    }
    cout << endl;
}
